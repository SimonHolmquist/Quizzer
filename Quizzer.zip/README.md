﻿# Quizzer

App Windows local para gestionar exÃ¡menes multiple-choice con versionado, editor interno, intentos, reportes y repeticiÃ³n espaciada.

Estado: scaffolding + base de arquitectura (Domain/Application/Infrastructure/Desktop).
