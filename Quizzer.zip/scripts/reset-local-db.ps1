﻿# TODO: cuando definamos la ruta real de la db, borrar el archivo aquÃ­.
Write-Host ""Pendiente: definir ruta de SQLite y borrar el archivo .db""
