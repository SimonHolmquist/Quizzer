﻿dotnet ef database update --project src/Quizzer.Infrastructure --startup-project src/Quizzer.Desktop
