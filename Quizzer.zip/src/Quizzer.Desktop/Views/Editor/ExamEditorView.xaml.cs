﻿namespace Quizzer.Desktop.Views.Editor;

public partial class ExamEditorView : System.Windows.Controls.UserControl
{
    public ExamEditorView()
    {
        InitializeComponent();
    }
}
