﻿namespace Quizzer.Desktop.Views.Reports;

public partial class ReportsView : System.Windows.Controls.UserControl
{
    public ReportsView()
    {
        InitializeComponent();
    }
}
