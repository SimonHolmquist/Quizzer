﻿namespace Quizzer.Desktop.Views.Exams;

public partial class ExamsListView : System.Windows.Controls.UserControl
{
    public ExamsListView()
    {
        InitializeComponent();
    }
}
