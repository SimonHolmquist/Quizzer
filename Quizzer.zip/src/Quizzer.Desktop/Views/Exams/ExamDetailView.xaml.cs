﻿namespace Quizzer.Desktop.Views.Exams;

public partial class ExamDetailView : System.Windows.Controls.UserControl
{
    public ExamDetailView()
    {
        InitializeComponent();
    }
}
