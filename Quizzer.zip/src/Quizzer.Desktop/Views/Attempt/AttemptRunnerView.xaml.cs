﻿namespace Quizzer.Desktop.Views.Attempt;

public partial class AttemptRunnerView : System.Windows.Controls.UserControl
{
    public AttemptRunnerView()
    {
        InitializeComponent();
    }
}
