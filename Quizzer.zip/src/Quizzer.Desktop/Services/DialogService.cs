﻿namespace Quizzer.Desktop.Services;

public sealed class DialogService
{
    // TODO: confirmaciones, errores, etc.
}
