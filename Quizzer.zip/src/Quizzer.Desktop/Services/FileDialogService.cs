﻿namespace Quizzer.Desktop.Services;

public sealed class FileDialogService
{
    // TODO: abrir/guardar CSV
}
