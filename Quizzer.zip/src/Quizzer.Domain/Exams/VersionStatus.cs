﻿namespace Quizzer.Domain;

// Quizzer.Domain

public enum VersionStatus { Draft = 0, Published = 1 }
