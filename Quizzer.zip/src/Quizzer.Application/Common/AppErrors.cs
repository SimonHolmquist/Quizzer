namespace Quizzer.Application.Common;

public static class AppErrors
{
    public const string NotFound = "No encontrado.";
    public const string ValidationFailed = "Validación fallida.";
}
