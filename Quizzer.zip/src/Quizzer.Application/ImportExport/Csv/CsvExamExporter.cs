﻿namespace Quizzer.Application.ImportExport.Csv;

public static class CsvExamExporter
{
    // TODO: exportar una versiÃ³n a CSV (question;option1..N;answer;explanation;tags;difficulty)
}
