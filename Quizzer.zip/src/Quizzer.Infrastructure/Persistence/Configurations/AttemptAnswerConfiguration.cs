﻿namespace Quizzer.Infrastructure.Persistence.Configurations; // TODO: fluent config

