using Xunit;

namespace Quizzer.Tests.Application;

public sealed class CsvImportTests
{
    [Fact]
    public void Placeholder() => Assert.True(true);
}
